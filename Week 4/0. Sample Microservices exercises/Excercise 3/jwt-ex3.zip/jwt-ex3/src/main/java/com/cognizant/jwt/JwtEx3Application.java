package com.cognizant.jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtEx3Application {

	public static void main(String[] args) {
		SpringApplication.run(JwtEx3Application.class, args);
	}

}
