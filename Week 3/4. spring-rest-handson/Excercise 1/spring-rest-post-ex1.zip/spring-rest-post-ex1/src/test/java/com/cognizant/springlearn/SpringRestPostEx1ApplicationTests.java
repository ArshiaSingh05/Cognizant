package com.cognizant.springlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestPostEx1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
