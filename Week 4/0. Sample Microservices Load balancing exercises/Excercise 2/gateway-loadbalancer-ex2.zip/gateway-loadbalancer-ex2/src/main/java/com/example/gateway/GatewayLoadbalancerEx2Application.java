package com.example.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayLoadbalancerEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(GatewayLoadbalancerEx2Application.class, args);
	}

}
