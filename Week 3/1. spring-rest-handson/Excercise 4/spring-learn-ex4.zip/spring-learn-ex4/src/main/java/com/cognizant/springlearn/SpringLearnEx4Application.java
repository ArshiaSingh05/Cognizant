package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnEx4Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearnEx4Application.class, args);
	}

}
