package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestEx2Application.class, args);
	}

}
