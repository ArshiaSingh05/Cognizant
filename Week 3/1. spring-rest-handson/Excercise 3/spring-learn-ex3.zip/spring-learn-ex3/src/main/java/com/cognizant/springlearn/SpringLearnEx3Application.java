package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringLearnEx3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringLearnEx3Application.class, args);
	}

}
